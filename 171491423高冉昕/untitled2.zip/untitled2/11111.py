import pandas as pd
from sklearn import tree #导入决策树模块
import graphviz #导入可视化模块

#导入数据
data=pd.read_excel(r'C:\Users\huangjunwen\Desktop\sales_data.xls')

#对数据进行清理
data=data.replace([['好','是','高']],1)#将数据集中的好，是，高替换成数字1
data=data.replace([['坏','否','低']],-1)#将数据及中的坏，否，低替换成数字-1
x=data.iloc[:,1:4]#选择训练集
y=data.iloc[:,4]#选择对应目标标签

#创建决策树模型并设置参数
dtc=tree.DecisionTreeClassifier(criterion='entropy')#创建基于信息熵的模型
dtc.fit(x,y)#训练模型

#模型输出
dot_data = \  #设置输出的参数
    tree.export_graphviz(
            dtc, #（决策树模型）
            out_file = None,
            feature_names = ['天气','周末','促销'], #模型中对应标签名称
            filled = True,
            impurity = False,
            rounded = True
    )
dot_data=dot_data.replace('helvetica','"Microsoft Yahei"')
#因为标签是中文所以需要将参数设置成支持微软雅黑的格式

graph=graphviz.Source(dot_data)#选择要可视化的dot数据
graph.render(r'C:\Users\huangjunwen\Desktop\tree')#将可视化结果输出至指定位置