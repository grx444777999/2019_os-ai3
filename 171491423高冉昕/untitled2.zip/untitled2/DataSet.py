
import pickle
import gzip

# third-party library
import numpy as np

def load_data(file):
    '''
    从文件中读取序列化的数据集
    :param file: 文件目录
    :return: 序列化的训练集，验证集，测试集
    '''
    f=gzip.open(file,'rb')
    trainning_data,validation_data,test_data=\
        pickle.load(f,encoding='iso-8859-1')
    f.close()
    return trainning_data,validation_data,test_data

def load_data_wrapper(file):
    '''
    1.将数据集分成（x，y），其中y是标签 
    :return: 
    '''
    tr_d,va_d,te_d=load_data(file)
    train_inputs=[np.reshape(x,(784,1)) for x in tr_d[0]]
    train_result=[vectorized_reslut(y) for y in tr_d[1]]
    train_data=list(zip(train_inputs,train_result))

    v_inputs=[np.reshape(x,(784,1)) for x in va_d[0]]
    v_data=list(zip(v_inputs,va_d[1]))
    test_inputs=[np.reshape(x,(784,1)) for x in te_d[0]]
    test_data=list(zip(test_inputs,te_d[1]))

    return train_data,v_data,test_data

def vectorized_reslut(j):
    '''
    one-hot 向量化
    :param j: 类别
    :return: 
    '''
    e=np.zeros((10,1))
    e[j]=1.0
    return e